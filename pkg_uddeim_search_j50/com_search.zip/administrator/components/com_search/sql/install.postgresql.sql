CREATE TABLE "#__core_log_searches" (
  "search_term" varchar(128) DEFAULT '' NOT NULL,
  "hits" bigint DEFAULT 0 NOT NULL
);
