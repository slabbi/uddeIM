DROP TABLE IF EXISTS `#__core_log_searches`;
