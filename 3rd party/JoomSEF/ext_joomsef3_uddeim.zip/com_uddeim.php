<?php
/**
 * @author       Denis Duli�i
 * @copyright   http://www.cozumweb.com
 * @package     ext_com_uddeim
 * @version      2.0.0
 */

defined('_JEXEC') or die('Restricted access.');

class SefExt_com_uddeim extends SefExt
{
    function create(&$uri) {
        $sefConfig =& SEFConfig::getConfig();
        $database =& JFactory::getDBO();
        
        $vars = $uri->getQuery(true);
		
        extract($vars);
		
        $title = array();
        $title[] = JoomSEF::_getMenuTitle(@$option, @$task, @$Itemid);
		
        if (isset($messageid)) {
            $sql = "SELECT id FROM #__uddeim WHERE id =".$messageid;
            $database->setQuery($sql);
            if ($mesaj = $database->loadResult()) {
                $title[] = $mesaj;
            }
            unset($vars['messageid']);
            if ($task == 'show') unset($task);
        }
		if ($task == 'outbox') {
			$title[] = _UDDEIM_OUTBOX;
			unset($task);
        }
		if ($task == 'inbox') {
			$title[] = _UDDEIM_INBOX;
			unset($task);
        }
		if ($task == 'trashcan') {
			$title[] = _UDDEIM_TRASHCAN;
			unset($task);
        }
		if ($task == 'new') {
			$title[] = _UDDEIM_CREATE;
			unset($task);
        }
		if ($task == 'forward') {
			$title[] = _UDDEIM_FORWARDLINK;
			unset($task);
        }
		if ($task == 'about') {
			$title[] = _UDDEADM_ABOUT;
			unset($task);
        }
		if ($task == 'delete') {
			$title[] = _UDDEIM_DELETE;
			unset($task);
        }
		if ($task == 'help') {
			$title[] = _UDDEIM_HELP;
			unset($task);
        }
		if ($task == 'settings') {
			$title[] = _UDDEIM_OPTIONS;
			unset($task);
        }
		if ($task == 'markread') {
			$title[] = _UDDEIM_STATUS_READ;
			unset($task);
        }
		if ($task == 'markunread') {
			$title[] = _UDDEIM_STATUS_UNREAD;
			unset($task);
        }
        if (count($title) > 0) {
            $newUri = JoomSEF::_sefGetLocation($uri, $title, @$task, @$limit, @$limitstart, @$lang, $nonSefVars);
			
        }
        return $newUri;
    }
}
?>