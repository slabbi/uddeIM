sh404SEF plugin by mattfaulds
-----------------------------

It's not perfect as I can't see how to make the messages IDs SEF but there we are. 
Hope people find this useful.

Install com_uddeim.php in /components/com_sef/sef_ext

Will produce:

/my-messages/
/my-messages/outbox
/my-messages/trachcan
/my-messages/archive
/my-messages/compose

Enjoy!
