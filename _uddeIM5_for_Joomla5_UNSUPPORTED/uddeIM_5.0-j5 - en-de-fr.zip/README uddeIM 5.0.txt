this version of uddeIM (5.0) is based on version 4.0
and recoded to run on Joomla v5.0+  ONLY.

because of the strict namespace requirements this code is
NOT backward compatile to earlier Joomla versions.

earlier libraries included in v4.0 are removed !
so there are only the two libs included for use with Joomla 5:
admin.uddeimlib50.php
uddeimlib50.php

I have not removed the many version checks within the different files,
but the (admin.)uddeimlib.php, which selects the right library is gone.

also the OLD module and plugins are removed.
included modules and plugins are tested to run on Joomla 5

also the premium addons and templates are tested.

have fun

