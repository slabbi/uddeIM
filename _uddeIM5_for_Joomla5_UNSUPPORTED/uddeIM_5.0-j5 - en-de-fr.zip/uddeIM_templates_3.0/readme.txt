Since some people are running their site on very unreliable servers 
("10 cent mass hosting") and have run into troubles that the installer 
of Joomla timed out because of too little CPU time, I have splitted 
the uddeIM package into two:

1st package: uddeIM component
             (incl. default template)

             Install this package with the Joomla component installer.


2nd package: additional uddeIM templates

             You can upload these templates into
              {userhome}/components/com_uddeim/templates/
             e.g. using a ftp client or joomlaXplorer.
